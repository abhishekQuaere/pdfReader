---
name: Request a Feature
about: What do you think is missing in pypdf?
title: ''
labels: Feature Request
assignees: ''

---

## Explanation

Explain briefly what you want to achieve.

## Code Example

How would your feature be used? (Remove this if it is not applicable.)

```python
from pypdf import PdfReader, PdfWriter

...  # your new feature in action!
```
