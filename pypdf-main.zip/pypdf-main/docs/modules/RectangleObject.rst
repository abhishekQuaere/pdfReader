The RectangleObject Class
-------------------------

.. autoclass:: pypdf.generic.RectangleObject
    :members:
    :undoc-members:
    :show-inheritance:
